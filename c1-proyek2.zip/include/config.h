#ifndef CONFIG_H
#define CONFIG_H

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define PLAYER_CAR_WIDTH 120
#define PLAYER_CAR_HEIGHT 120

#endif // CONFIG_H