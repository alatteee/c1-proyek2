// jalur.h
#ifndef JALUR_H
#define JALUR_H

#include <SDL3/SDL.h>
#include "config.h"

void draw_lanes(SDL_Renderer *renderer);


#endif // JALUR_H