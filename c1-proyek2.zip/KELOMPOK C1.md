INI ADALAH MARKDOWN KELOMPOK C1 PROYEK 2

Jurusan Teknik Komputer dan Informatika

Program Studi D3 - Teknik Informatika

Proyek Manager : Pa Yudi Widhiyasana

Anggota:
- ERSYA HASBY SATRIA          - 241511072
- YAZID ALRASYID              - 241511093
- NIKE KUSTIANE               - 241511086
- AZKHA NAZZALA PRASADHA DIES - 241511069
- ANDHINI WIDYA PUTRI WASTIKA - 241511068

Target Proyek:
Menyelesaikan proyek 2 pembuatan game dengan judul game C1 Brick Racer

compile file:
gcc -g "C:/Users/.../main.c" "C:/Users/.../src/mobil.c" "C:/Users/.../src/jalur.c" "C:/Users/.../src/Main_menu.c" "C:/Users/.../src/rintangan.c" -o "C:/Users/.../src/main.exe" -I C:/MinGW/include -L C:/MinGW/lib -lmingw32 -lSDL3

Pembagian header
- Ersya - Main_menu.h
- Ala - mobil.h
- Nike - jalur.h
- Andin - skor.h
- Yazid - rintangan.h
